from django.shortcuts import render,HttpResponse

# Create your views here.

def show(request):
    return HttpResponse("HELLO 23417131 VISHNU")
